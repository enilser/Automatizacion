$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("prueba.feature");
formatter.feature({
  "line": 1,
  "name": "Prueba de Trabajo",
  "description": "",
  "id": "prueba-de-trabajo",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 3,
  "name": "Examen",
  "description": "",
  "id": "prueba-de-trabajo;examen",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 4,
  "name": "Abrimos el navegador y buscamos el sitio de ebay",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "buscamos \"\u003cobjeto\u003e\", elegimos la marca \"\u003cmarca\u003e\" con el tamaño \"\u003ctamanio\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "ejecutamos los demas procesos de la prueba",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "se deberia tener como minimo \"\u003ccantidad\u003e\" registros para la pregunta siete",
  "keyword": "Then "
});
formatter.examples({
  "line": 9,
  "name": "",
  "description": "",
  "id": "prueba-de-trabajo;examen;",
  "rows": [
    {
      "cells": [
        "objeto",
        "marca",
        "tamanio",
        "cantidad"
      ],
      "line": 10,
      "id": "prueba-de-trabajo;examen;;1"
    },
    {
      "cells": [
        "shoes",
        "PUMA",
        "10",
        "5"
      ],
      "line": 11,
      "id": "prueba-de-trabajo;examen;;2"
    },
    {
      "cells": [
        "shoes",
        "PRADA",
        "9.5",
        "5"
      ],
      "line": 12,
      "id": "prueba-de-trabajo;examen;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 11,
  "name": "Examen",
  "description": "",
  "id": "prueba-de-trabajo;examen;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 4,
  "name": "Abrimos el navegador y buscamos el sitio de ebay",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "buscamos \"shoes\", elegimos la marca \"PUMA\" con el tamaño \"10\"",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "ejecutamos los demas procesos de la prueba",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "se deberia tener como minimo \"5\" registros para la pregunta siete",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "PruebaEnilser.abrimos_el_navegador_y_buscamos_el_sitio_de_ebay()"
});
formatter.result({
  "duration": 60382076842,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "shoes",
      "offset": 10
    },
    {
      "val": "PUMA",
      "offset": 37
    },
    {
      "val": "10",
      "offset": 58
    }
  ],
  "location": "PruebaEnilser.buscamos_elegimos_la_marca_con_el_tamaño(String,String,String)"
});
formatter.result({
  "duration": 33613643813,
  "status": "passed"
});
formatter.match({
  "location": "PruebaEnilser.ejecutamos_los_demas_procesos_de_la_prueba()"
});
formatter.result({
  "duration": 11955162266,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5",
      "offset": 30
    }
  ],
  "location": "PruebaEnilser.se_deberia_tener_como_minimo_registros_para_la_pregunta_siete(String)"
});
formatter.result({
  "duration": 1754044294,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Examen",
  "description": "",
  "id": "prueba-de-trabajo;examen;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 4,
  "name": "Abrimos el navegador y buscamos el sitio de ebay",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "buscamos \"shoes\", elegimos la marca \"PRADA\" con el tamaño \"9.5\"",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "ejecutamos los demas procesos de la prueba",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "se deberia tener como minimo \"5\" registros para la pregunta siete",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "PruebaEnilser.abrimos_el_navegador_y_buscamos_el_sitio_de_ebay()"
});
formatter.result({
  "duration": 16001532111,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "shoes",
      "offset": 10
    },
    {
      "val": "PRADA",
      "offset": 37
    },
    {
      "val": "9.5",
      "offset": 59
    }
  ],
  "location": "PruebaEnilser.buscamos_elegimos_la_marca_con_el_tamaño(String,String,String)"
});
formatter.result({
  "duration": 27011777004,
  "status": "passed"
});
formatter.match({
  "location": "PruebaEnilser.ejecutamos_los_demas_procesos_de_la_prueba()"
});
formatter.result({
  "duration": 14519759441,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5",
      "offset": 30
    }
  ],
  "location": "PruebaEnilser.se_deberia_tener_como_minimo_registros_para_la_pregunta_siete(String)"
});
formatter.result({
  "duration": 338220892,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"id\",\"selector\":\"GalleryViewInner\"}\n  (Session info: chrome\u003d65.0.3325.181)\n  (Driver info: chromedriver\u003d2.37.544315 (730aa6a5fdba159ac9f4c1e8cbc59bf1b5ce12b7),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 331 milliseconds\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.0.1\u0027, revision: \u00271969d75\u0027, time: \u00272016-10-18 09:49:13 -0700\u0027\nSystem info: host: \u0027user-PC\u0027, ip: \u0027192.168.0.224\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_161\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{applicationCacheEnabled\u003dfalse, rotatable\u003dfalse, mobileEmulationEnabled\u003dfalse, networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d2.37.544315 (730aa6a5fdba159ac9f4c1e8cbc59bf1b5ce12b7), userDataDir\u003dC:\\Windows\\TEMP\\scoped_dir4792_30784}, takesHeapSnapshot\u003dtrue, pageLoadStrategy\u003dnormal, databaseEnabled\u003dfalse, handlesAlerts\u003dtrue, hasTouchScreen\u003dfalse, version\u003d65.0.3325.181, platform\u003dXP, browserConnectionEnabled\u003dfalse, nativeEvents\u003dtrue, acceptSslCerts\u003dfalse, acceptInsecureCerts\u003dfalse, locationContextEnabled\u003dtrue, webStorageEnabled\u003dtrue, browserName\u003dchrome, takesScreenshot\u003dtrue, javascriptEnabled\u003dtrue, cssSelectorsEnabled\u003dtrue, setWindowRect\u003dtrue, unexpectedAlertBehaviour\u003d}]\nSession ID: 53995ceb14564a9c9d5fb3bd55723d0d\n*** Element info: {Using\u003did, value\u003dGalleryViewInner}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:216)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:168)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:635)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:368)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementById(RemoteWebDriver.java:417)\r\n\tat org.openqa.selenium.By$ById.findElement(By.java:218)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:360)\r\n\tat com.edu.eam.pruebasdeaceptacion.steps.PruebaEnilser.se_deberia_tener_como_minimo_registros_para_la_pregunta_siete(PruebaEnilser.java:79)\r\n\tat ✽.Then se deberia tener como minimo \"5\" registros para la pregunta siete(prueba.feature:7)\r\n",
  "status": "failed"
});
});